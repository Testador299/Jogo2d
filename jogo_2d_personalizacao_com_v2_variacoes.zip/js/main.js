
let autocomplete;
let cidadeSelecionada = null;

function initAutocomplete() {
  const input = document.getElementById("cidade");

  autocomplete = new google.maps.places.Autocomplete(input, {
    types: ["(cities)"],
    componentRestrictions: { country: ["br", "us"] }
  });

  autocomplete.addListener("place_changed", () => {
    const place = autocomplete.getPlace();
    if (!place.geometry) {
      alert("Por favor, selecione uma cidade da lista.");
      return;
    }

    cidadeSelecionada = {
      nome: place.name,
      latitude: place.geometry.location.lat(),
      longitude: place.geometry.location.lng(),
      pais: place.address_components.slice(-1)[0].long_name
    };
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initAutocomplete();

  const form = document.getElementById("playerForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const nome = document.getElementById("nome").value;
    const idade = parseInt(document.getElementById("idade").value);

    if (!cidadeSelecionada) {
      alert("Escolha uma cidade válida.");
      return;
    }

    const dados = {
      nome,
      idade,
      cidadeNatal: cidadeSelecionada
    };

    localStorage.setItem("jogador", JSON.stringify(dados));
    document.getElementById("resultado").innerText = `Jogador registrado: ${JSON.stringify(dados, null, 2)}`;
  });
});
